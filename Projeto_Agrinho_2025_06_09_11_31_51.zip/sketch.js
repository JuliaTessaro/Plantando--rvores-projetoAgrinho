let plantas = [];
let particulas = [];
let temperatura = 10;
let totalArvores = 0;
let jardineiro;

function setup() {
  createCanvas(600, 400);
  textAlign(LEFT, TOP);
  jardineiro = new Jardineiro(width / 2, height - 50);
}

function draw() {
  // Fundo muda conforme número de árvores
  let corFundo = lerpColor(color(217, 112, 26), color(219, 239, 208),
    map(totalArvores, 0, 100, 0, 1));
  background(corFundo);

  mostrarInformacoes();

  temperatura += 0.1;

  jardineiro.atualizar();
  jardineiro.mostrar();

  verificarFimDeJogo();

  // Mostrar árvores
  for (let arvore of plantas) {
    arvore.mostrar();
  }

  // Atualizar partículas
  for (let i = particulas.length - 1; i >= 0; i--) {
    particulas[i].atualizar();
    particulas[i].mostrar();
    if (!particulas[i].estaViva()) {
      particulas.splice(i, 1);
    }
  }

  // Efeito de calor
  if (temperatura > 40) {
    fill(255, 0, 0, 50);
    rect(0, 0, width, height);
  }
}

function mostrarInformacoes() {
  textSize(16);
  fill(0);
  text("🌡️ Temperatura: " + temperatura.toFixed(2), 10, 10);
  text("🌳 Árvores plantadas: " + totalArvores, 10, 30);
  text("🕹️ Use as setas do teclado para mover", 10, 50);
  text("🪴 Pressione 'p' ou espaço para plantar", 10, 70);
}

function verificarFimDeJogo() {
  if (totalArvores > temperatura) {
    mostrarMensagemVitoria();
  } else if (temperatura > 50) {
    mostrarMensagemDeDerrota();
  }
}

function mostrarMensagemVitoria() {
  textSize(20);
  fill(0);
  text("🎉 Você venceu! Você plantou muitas árvores!", 100, 200);
  noLoop();
}

function mostrarMensagemDeDerrota() {
  textSize(20);
  fill(255, 0, 0);
  text("😭 Você perdeu! A temperatura está muito alta.", 100, 200);
  noLoop();
}

class Jardineiro {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.emoji = '👩‍🌾';
    this.velocidade = 3;
  }

  atualizar() {
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= this.velocidade;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += this.velocidade;
    }
    if (keyIsDown(UP_ARROW)) {
      this.y -= this.velocidade;
    }
    if (keyIsDown(DOWN_ARROW)) {
      this.y += this.velocidade;
    }

    // Limitar movimento à tela
    this.x = constrain(this.x, 0, width - 32);
    this.y = constrain(this.y, 0, height - 32);
  }

  mostrar() {
    textSize(32);
    text(this.emoji, this.x, this.y);
  }
}

class Arvore {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.emoji = '🌳';
  }

  mostrar() {
    textSize(32);
    text(this.emoji, this.x, this.y);
  }
}

class Particula {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.vy = random(-1, -3);
    this.alpha = 255;
    this.size = random(5, 10);
  }

  atualizar() {
    this.y += this.vy;
    this.alpha -= 5;
  }

  mostrar() {
    noStroke();
    fill(34, 139, 34, this.alpha);
    ellipse(this.x, this.y, this.size);
  }

  estaViva() {
    return this.alpha > 0;
  }
}

function keyPressed() {
  // Plantar árvore com espaço ou tecla "p"
  if (key === ' ' || key === 'p' || key === 'P') {
    let arvore = new Arvore(jardineiro.x, jardineiro.y);
    plantas.push(arvore);
    totalArvores++;
    temperatura -= 3;
    if (temperatura < 0) temperatura = 0;

    // Criar partículas
    for (let i = 0; i < 10; i++) {
      particulas.push(new Particula(jardineiro.x, jardineiro.y));
    }
  }
}

